# flask-gridjs
Render beautiful tables in your Flask templates with grid.js

![Table Example](table.gif)
